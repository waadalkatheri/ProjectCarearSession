//
//  constants.swift
//  virtualTourists
//
//  Created by Najla Al qahtani on 1/20/19.
//  Copyright © 2019 Najla Al qahtani. All rights reserved.
//

import Foundation

class Constants {
    
    static let API_KEY: String = "e04a53f51f4809368643d7dc141f2f87"
}
