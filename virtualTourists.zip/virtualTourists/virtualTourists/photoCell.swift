//
//  photoCell.swift
//  virtualTourists
//
//  Created by Najla Al qahtani on 1/20/19.
//  Copyright © 2019 Najla Al qahtani. All rights reserved.
//

import UIKit

class photoCell: UICollectionViewCell {

    
    @IBOutlet weak var imageView: UIImageView!
    
}
